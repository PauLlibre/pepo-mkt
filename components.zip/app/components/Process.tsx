"use client"

import { useState, useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

// Register ScrollTrigger
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

// Example waypoints (adjust threshold and data as you wish)
const WAYPOINTS: Waypoint[] = [
  {
    id: 1,
    step: "Paso 1",
    title: "Análisis y Estrategia Personalizada",
    threshold: 0,
    description:
      "Estudiamos tu negocio, mercado y objetivos para diseñar una estrategia de marketing digital adaptada a tus necesidades.",
    side: "left",
  },
  {
    id: 2,
    step: "Paso 2",
    title: "Ejecución y Optimización",
    threshold: 0.5,
    description:
      "Implementamos campañas efectivas con herramientas avanzadas, ajustándolas continuamente para maximizar resultados.",
    side: "right",
  },
  {
    id: 3,
    step: "Paso 3",
    title: "Seguimiento y Crecimiento",
    threshold: 1,
    description:
      "Medimos el impacto de nuestras acciones, generando informes claros y ajustando la estrategia para garantizar el crecimiento constante.",
    side: "left",
  },
]

// Define a type for the waypoint
type Waypoint = {
  id: number
  title: string
  threshold: number
  description: string
  side: "left" | "right"
  step: string
}

export default function Process() {
  // Track the scroll progress (0.0 -> 1.0)
  const [progress, setProgress] = useState(0)
  const processRef = useRef<HTMLDivElement>(null)

  // Track which waypoints have been passed
  const [passedWaypoints, setPassedWaypoints] = useState<Set<number>>(new Set())

  useEffect(() => {
    if (!processRef.current) return

    // Initialize GSAP animations
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: processRef.current,
        start: "top 80%",
        end: "bottom 20%",
        scrub: 1,
        onUpdate: (self) => {
          setProgress(self.progress)

          // Update passed waypoints
          const newPassedWaypoints = new Set<number>()
          WAYPOINTS.forEach((wp) => {
            if (self.progress >= wp.threshold) {
              newPassedWaypoints.add(wp.id)
            }
          })
          setPassedWaypoints(newPassedWaypoints)
        },
      },
    })

    // Animate the line
    tl.to(".process-line-fill", {
      height: "100%",
      ease: "none",
    })

    return () => {
      if (tl.scrollTrigger) {
        tl.scrollTrigger.kill()
      }
    }
  }, [])

  return (
    <div className="py-20 px-4">
      <h2 className="text-center text-3xl sm:text-4xl md:text-5xl font-bold mb-16">Nuestro Proceso</h2>

      <div ref={processRef} className="relative w-full h-[100vh] flex justify-center items-start">
        {/* The background line (gray), spanning the full page height. */}
        <div
          className="
            absolute 
            top-0
            left-1/2
            -translate-x-1/2
            w-1
            bg-gray-700
            h-full
            rounded-full
          "
        />

        {/* The filled line (#ff4500) that grows as we scroll. */}
        <div
          className="
            process-line-fill
            absolute
            top-0
            left-1/2
            -translate-x-1/2
            w-1
            bg-gradient-to-b from-[#ff4500] to-[#ff7e50]
            h-0
            rounded-full
            shadow-[0_0_10px_rgba(255,69,0,0.5)]
          "
        />

        {/* Waypoints (dots) */}
        {WAYPOINTS.map((wp) => {
          const dotTop = `${wp.threshold * 100}%`
          const isPastThreshold = progress >= wp.threshold

          return (
            <div
              key={wp.id}
              className="absolute left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-gray-800 border-2 border-gray-600 z-10 transition-all duration-500"
              style={{
                top: dotTop,
                transform: "translate(-50%, -50%)",
              }}
            >
              {/* If we are past this waypoint's threshold, color it #ff4500 */}
              <div
                className={`w-full h-full rounded-full transition-all duration-500 flex items-center justify-center ${
                  isPastThreshold ? "bg-[#ff4500] shadow-[0_0_15px_rgba(255,69,0,0.7)]" : "bg-transparent"
                }`}
              >
                <span className="text-xs font-bold">{wp.id}</span>
              </div>
            </div>
          )
        })}

        {/* Info panels for all passed waypoints */}
        {WAYPOINTS.filter((wp) => passedWaypoints.has(wp.id)).map((wp) => (
          <div
            key={wp.id}
            className={`
              absolute
              ${wp.side === "left" ? "right-[52%]" : "left-[52%]"}
              text-white
              p-6
              rounded-lg
              shadow-lg
              w-80
              transition-all
              duration-500
              bg-black/30
              backdrop-blur-sm
              border
              border-white/10
            `}
            style={{
              top: `${wp.threshold * 100}%`,
              transform: "translateY(-50%)",
              opacity: progress >= wp.threshold ? 1 : 0,
            }}
          >
            <h3 className="font-bold text-xl mb-2 text-[#ff4500]">{wp.step}</h3>
            <h2 className="font-bold text-2xl mb-3">{wp.title}</h2>
            <p className="text-white/80">{wp.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

