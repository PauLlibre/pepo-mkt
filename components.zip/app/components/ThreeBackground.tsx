"use client"

import { useRef, useEffect } from "react"
import * as THREE from "three"
import { useFrame, Canvas } from "@react-three/fiber"
import { Float, Environment } from "@react-three/drei"
import { gsap } from "gsap"
import { InstancedMesh } from "three"
import { SphereGeometry, MeshStandardMaterial } from "three"

// Define a proper particle data interface
interface ParticleData {
  position: number[];
  scale: number;
  rotation: number;
  color: THREE.Color;
}

// Animated particles that follow the mouse
function Particles({ count = 2000, mouse }: { count: number; mouse: React.MutableRefObject<number[]> }) {
  const mesh = useRef<InstancedMesh>(null)
  const dummy = new THREE.Object3D()

  // Create particles
  const particles = useRef<ParticleData[]>([])
  const colorArray = [new THREE.Color("#ff4500"), new THREE.Color("#ff7e50"), new THREE.Color("#ff9e7a")]

  useEffect(() => {
    // Initialize particles
    particles.current = new Array(count).fill(0).map(() => ({
      position: [Math.random() * 10 - 5, Math.random() * 10 - 5, Math.random() * 10 - 5],
      scale: Math.random() * 0.2 + 0.05,
      rotation: Math.random() * Math.PI,
      color: colorArray[Math.floor(Math.random() * colorArray.length)],
    }))
  }, [count])

  useFrame((state) => {
    if (!particles.current || !mesh.current) return

    // Update particles
    particles.current.forEach((particle, i) => {
      const { position, scale, rotation, color } = particle

      // Move towards mouse with different speeds for parallax effect
      const mouseInfluence = (0.05 * ((i % 3) + 1)) / 3

      dummy.position.set(
        position[0] + mouse.current[0] * mouseInfluence,
        position[1] + mouse.current[1] * mouseInfluence,
        position[2],
      )

      dummy.scale.set(scale, scale, scale)
      dummy.rotation.set(rotation, rotation, rotation)
      dummy.updateMatrix()

      mesh.current!.setColorAt(i, color)
      mesh.current!.setMatrixAt(i, dummy.matrix)
    })

    mesh.current!.instanceMatrix.needsUpdate = true
    if (mesh.current!.instanceColor) mesh.current!.instanceColor.needsUpdate = true
  })

  const sphereGeo = new SphereGeometry(0.05, 8, 8)
  const material = new MeshStandardMaterial({ roughness: 0.5, metalness: 0.2 })

  return (
    <instancedMesh ref={mesh} args={[sphereGeo, material, count]}>
    </instancedMesh>
  )
}

// Floating 3D logo
function Logo(props: JSX.IntrinsicElements['mesh']) {
  const mesh = useRef<THREE.Mesh>(null)

  useEffect(() => {
    if (!mesh.current) return

    // Animate logo on mount
    gsap.from(mesh.current.position, {
      y: -2,
      duration: 2,
      ease: "elastic.out(1, 0.5)",
    })

    gsap.from(mesh.current.rotation, {
      y: Math.PI * 2,
      duration: 2.5,
      ease: "power3.out",
    })
  }, [])

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <mesh ref={mesh} {...props}>
        <torusKnotGeometry args={[0.7, 0.3, 100, 16]} />
        <meshStandardMaterial
          color="#ff4500"
          roughness={0.3}
          metalness={0.8}
          emissive="#ff4500"
          emissiveIntensity={0.2}
        />
      </mesh>
    </Float>
  )
}

export default function ThreeBackground() {
  const mouse = useRef<number[]>([0, 0])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Normalize mouse coordinates
      mouse.current = [(e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1]
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  return (
    <div className="fixed top-0 left-0 w-full h-full z-0 opacity-70">
      <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <Particles count={1500} mouse={mouse} />
        <Logo position={[0, 0, -2]} />
        <Environment preset="city" />
      </Canvas>
    </div>
  )
}

