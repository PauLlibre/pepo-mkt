"use client"

import { useState, useEffect, useRef } from "react"
import { gsap } from "gsap"

export default function CustomCursor() {
  // The circle's *actual* position on the screen
  const [pos, setPos] = useState({ x: 0, y: 0 })
  // The circle's *target* position (where the mouse is)
  const targetRef = useRef({ x: 0, y: 0 })
  const cursorRef = useRef(null)
  const cursorBorderRef = useRef(null)

  // Capture the user's actual mouse position
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      targetRef.current = { x: e.clientX, y: e.clientY }
    }

    // Handle hover states
    const handleMouseEnter = () => {
      if (!cursorRef.current) return
      gsap.to(cursorRef.current, {
        scale: 1.5,
        opacity: 0.5,
        duration: 0.3,
      })
    }

    const handleMouseLeave = () => {
      if (!cursorRef.current) return
      gsap.to(cursorRef.current, {
        scale: 1,
        opacity: 1,
        duration: 0.3,
      })
    }

    // Add event listeners
    window.addEventListener("mousemove", handleMouseMove)

    // Add hover effect for interactive elements
    const interactiveElements = document.querySelectorAll('a, button, [role="button"]')
    interactiveElements.forEach((el) => {
      el.addEventListener("mouseenter", handleMouseEnter)
      el.addEventListener("mouseleave", handleMouseLeave)
    })

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      interactiveElements.forEach((el) => {
        el.removeEventListener("mouseenter", handleMouseEnter)
        el.removeEventListener("mouseleave", handleMouseLeave)
      })
    }
  }, [])

  // Animation loop: gradually move `pos` towards `targetRef`
  useEffect(() => {
    let frameId: number

    const animate = () => {
      setPos((prevPos) => {
        const dx = targetRef.current.x - prevPos.x
        const dy = targetRef.current.y - prevPos.y
        const speed = 0.1 // increase to move faster, decrease to move slower

        return {
          x: prevPos.x + dx * speed,
          y: prevPos.y + dy * speed,
        }
      })
      frameId = requestAnimationFrame(animate)
    }

    animate() // start animation
    return () => cancelAnimationFrame(frameId)
  }, [])

  // Add outer ring cursor
  useEffect(() => {
    if (!cursorBorderRef.current) return

    const moveCursorBorder = () => {
      gsap.to(cursorBorderRef.current, {
        x: targetRef.current.x,
        y: targetRef.current.y,
        duration: 0.15,
        ease: "power2.out",
      })
    }

    gsap.ticker.add(moveCursorBorder)

    return () => {
      gsap.ticker.remove(moveCursorBorder)
    }
  }, [])

  return (
    <>
      <div
        ref={cursorRef}
        className="pointer-events-none fixed top-0 left-0 z-[9999] 
                  h-3 w-3 rounded-full bg-[#ff4500] 
                  transform -translate-x-1/2 -translate-y-1/2
                  shadow-[0_0_15px_rgba(255,69,0,0.6)] transition-all duration-300"
        style={{
          transform: `translate(${pos.x}px, ${pos.y}px)`,
        }}
      />
      <div
        ref={cursorBorderRef}
        className="pointer-events-none fixed top-0 left-0 z-[9998] 
                  h-8 w-8 rounded-full border border-[#ff4500] 
                  transform -translate-x-1/2 -translate-y-1/2
                  transition-transform duration-300"
      />
    </>
  )
}

