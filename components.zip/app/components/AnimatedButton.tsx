"use client"

import type React from "react"
import { useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { gsap } from "gsap"

interface AnimatedButtonProps {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export default function AnimatedButton({ children, className = "", onClick }: AnimatedButtonProps) {
  const buttonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!buttonRef.current) return

    // Create hover animation
    const button = buttonRef.current

    const onEnter = () => {
      gsap.to(button, {
        scale: 1.05,
        duration: 0.3,
        ease: "power2.out",
      })

      gsap.to(button, {
        boxShadow: "0 0 15px rgba(255, 69, 0, 0.7)",
        duration: 0.3,
      })
    }

    const onLeave = () => {
      gsap.to(button, {
        scale: 1,
        duration: 0.3,
        ease: "power2.out",
      })

      gsap.to(button, {
        boxShadow: "0 0 0px rgba(255, 69, 0, 0)",
        duration: 0.3,
      })
    }

    button.addEventListener("mouseenter", onEnter)
    button.addEventListener("mouseleave", onLeave)

    return () => {
      button.removeEventListener("mouseenter", onEnter)
      button.removeEventListener("mouseleave", onLeave)
    }
  }, [])

  return (
    <Button ref={buttonRef} className={`transition-all ${className}`} onClick={onClick}>
      {children}
    </Button>
  )
}

